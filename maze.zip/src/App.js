
import './App.css';
import F from './components/FindSolution'
function App() {
  return (
    <div className="App">
      <h2 className="head"> Maze Game </h2>
      <F/>
    </div>
  );
}

export default App;
